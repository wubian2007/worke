<html>

<head>
<meta charset="utf-8">
<title>客户系统</title>
<link rel="stylesheet" type="text/css" href="theme.css">
<?php include('./ceshi.php'); ?>
</head>
<ul>
  <li><a class="active" href="#home">主页</a></li>
  <li><a href="/3d/3dw.php">3D客户订单</a></li>
  <li><a href="/p3/p3w.php">P3客户订单</a></li>
  <li><a href="https://web.skype.com">skype通讯会议</a></li> 
</ul>
<body>

    


<html>
<body>
<h1>请选择对应的数据表</h1>
<iframe src ="/p3/p3w.php" width="700re" height="900px" frameborder="0">
    
 
</iframe>
 
<iframe src ="/3d/3dw.php" width="700re" height="900px" frameborder="0">
    
 
</iframe>
</body>
</html>
</body>

</html>


