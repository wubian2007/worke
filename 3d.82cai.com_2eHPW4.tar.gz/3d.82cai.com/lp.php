<html>

<head>
<meta charset="utf-8">
<title>系统-LD-P3</title>
<link rel="stylesheet" type="text/css" href="/theme.css">
<?php include('./password/ps-ld.php'); ?>
<?php include('./htm/head.php');//调用的头部文件 ?> 
</head>

<body>

    

<html>
<body>
<iframe src ="/p3/p3-l.php" width="380px" height="900px" frameborder="0">
    
 
</iframe>
 
<iframe src ="/fenjie.php" width="450px" height="900px" frameborder="0">
    
 
</iframe>


<iframe src ="/p3/p3zx.php" width="400px" height="900px" frameborder="0">
    
</iframe>

<iframe src ="/p3/p3zx2l.php" width="400px" height="900px" frameborder="0">
    
</iframe>
</body>

</html>


