<html>

<head>

<title>P3客户订单</title>

<?php include('../ceshi.php'); ?>

</head>

<ul>
  <li><a class="active" href="/">主页</a></li>
  <li><a href="/3d/3d.php">3D客户订单</a></li>
  <li><a href="/3d/p3.php">P3客户订单</a></li>
  <li><a href="https://web.skype.com">skype通讯会议</a></li> 
</ul>
<body>
<p><h1>P3客户订单</h1></p>
</center>
<center>

<form action="" method="post">
<input type="text" class="layui-input" name="startdata" placeholder="请选择开始日期" id="test1" style="min-width: 274px;" lay-key="1">
<input type="text" class="layui-input" name="overdata" placeholder="请选择结束日期" id="test2" style="min-width: 274px;" lay-key="2">
<input type="submit" value="搜索">
</form>
<script src='/src/js/laydate.js'></script>
<script>

//常规用法
laydate.render({
  elem: '#test1'
});
//国际版
laydate.render({
  elem: '#test2'
  
}); 
</script>
<?php



$db_host='localhost';      //MYSQL服务器名

$db_user="3dp3";       //MYSQL用户名

$db_pass="aabb8899";       //MYSQL用户对应密码

$db_name="3dp3";      //要操作的数据库

//使用mysql_connect()函数对服务器进行连接，如果出错返回相应信息

$link=mysqli_connect($db_host,$db_user,$db_pass)or die("不能连接到服务器".mysqli_error());

mysqli_select_db($link,$db_name);   //选择相应的数据库，这里选择test库

$sql="select * from P3 where crtime> curdate()";     //先执行SQL语句显示所有记录以与插入后相比较

$result=mysqli_query($link,$sql);   //使用mysql_query()发送SQL请求

if($_POST['startdata'] and $_POST['overdata']){
	$sql="select * from P3 where data>'{$_POST['startdata']}' and data<'{$_POST['overdata']}'";
	//echo $sql;
	$result=mysqli_query($link,$sql);
}
if($_POST['del']){ //点击提交按钮后才执行  

        $sql2 = "truncate P3";//从数据库中查询数据

        	$query = mysqli_query($link,$sql2);

        	$row = mysqli_fetch_assoc($query);//数据结果集

        	header("location:./p3.php");

    }
if(@$_GET['act'] =='update'){ //更新是否点击
	$id = $_GET['id'];
   
	$sql="update P3 set shuru='YES',user='T' where id=".$id;     //先执行SQL语句显示所有记录以与插入后相比较

	$result=mysqli_query($link,$sql);   //使用mysql_query()发送SQL请求
	echo json_encode($result);exit;
}
if ($query2)
    //header("location:delP3ZX.php");
    //header("location:zxjsq.html");

echo "当前表中的记录有：";

echo "<table id=t1 border=1 style=word-break:break-all; word-wrap:break-all;>";     //使用表格格式化数据

echo "<tr>
          <td width=50>编号</td>
          <td width=180>日期</td>
          <td width=180>订单</td>
          <td width=80>一键复制</td>          
          <td width=100>金额</td>
          <td width=50>处理人</td>
          <td width=70>分解订单</td>
          <td width=70>中奖</td>
      </tr>";

while($row=mysqli_fetch_array($result))  //遍历SQL语句执行结果把值赋给数组

{

  echo "<tr>";

 echo "<td>".$row['id']."</td>";   //显示ID
 echo "<td>".$row['crtime']." </td>";  //显示日期
 echo "<td><p id=p".$row['id'].">".$row['message']." </p ></td>";  //显示订单
 echo "<td><button data-id=".$row['id'].">复制处理</button></td>";  //显示地址
 echo "<td>".$row['jiner']." </td>";    //显示金额
 echo "<td>".$row['shuru']." </td>";    //显示是否处理

 //if($row['shuru']){
//	 echo "<td id='shuru".$row['id']."'>否</td>";
 //}else{
//	 echo "<td id='shuru".$row['id']."'>是</td>";   
// } 
 echo "<td>".$row['gfdd']." </td>";    //显示是否处理
 echo "<td>".$row['zj']." </td>"; 
 echo "</tr>";

}

echo "</table>";

?>

<form name="biao1" id="biao1" method="POST" action="">
<p>提交订单</p>

<p>金额（可以不写）<input type="text" style="width:150px; height:30px;" name="num3" id="num3" />
订单：<input type="text" style="width:250px; height:100px;" name="beishu3" id="beishu3"  /></p>
</center>
<p style="text-align:center;"><input type="submit" value="提交" class="btn btn-default" style="width:100px; height:30px;" onclick="javascript:this.form.action='../msgp3.php';"></p>
</form>
</center>

</center>

<textarea id="input" rows="5" cols="150">这里核对被复制的内容</textarea>

<script>

	var but=document.getElementsByTagName('button');

	 for(i=0;i<but.length;i++){

		 but[i].setAttribute('i',i+1);

		 but[i].onclick=function(){

			 b=this.getAttribute('i');

			 //alert('这是第'+b+'个按钮');

			 var pcolor='p'+b;

			 var text = document.getElementById(pcolor).innerText;

			var input = document.getElementById("input");

			input.value = text; // 修改文本框的内容

			input.select(); // 选中文本

			document.execCommand("copy"); // 执行浏览器复制命令

			alert('第'+b+'组复制成功');
			var nid = this.getAttribute('data-id');
			Ajax.get('/3d/3d.php?act=update&id='+nid,nid);
			document.getElementById(pcolor).style.background='red';

			 }

	}
	
	var Ajax={
	  get: function(url,id, fn) {
		// XMLHttpRequest对象用于在后台与服务器交换数据   
		var xhr = new XMLHttpRequest();            
		xhr.open('GET', url, true);
		xhr.onreadystatechange = function() {
			document.getElementById('shuru'+id).innerHTML ='YES';
		};
		xhr.send();
	  }
	}

 </script>

<script type="text/javascript"> // 这个是可以根据条件修改内容的代码
<!--
function changeCellColor(sTableId)
{
    var oTbe = document.getElementById(sTableId);
    var td;
    for (var i=0; i<oTbe.rows.length; i++)
    {
        for (var j=0; j<oTbe.rows[i].cells.length; j++)
        {
            with (oTbe.rows[i].cells[j])
            {
                style.background = (innerHTML.indexOf("YES") > -1)?"blue":"while"; //如果包含‘是’ 背景锯齿 蓝色，不然就红色
            }
        }
    }
}
 
changeCellColor("t1");  //这里是要修改的表字， 需要你提前定义好
changeCellColor("tbe03");
//-->
</script>

</body>

</html>