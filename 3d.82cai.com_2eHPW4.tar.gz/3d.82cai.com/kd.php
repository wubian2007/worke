<html>

<head>
<meta charset="utf-8">
<title>系统-KS</title>
<link rel="stylesheet" type="text/css" href="/theme.css">
<?php include('./password/ps-ks.php'); ?>
<?php include('./htm/head.php');//调用的头部文件 ?> 
</head>

<body>

    

<html>
<body>
<iframe src ="/3d/3d-k.php" width="380px" height="900px" frameborder="0">
    
 
</iframe>
 
<iframe src ="/fenjie.php" width="450px" height="900px" frameborder="0">
    
 
</iframe>


<iframe src ="/3d/3dzx.php" width="400px" height="900px" frameborder="0">
    
</iframe>

<iframe src ="/3d/3dzx2k.php" width="400px" height="900px" frameborder="0">
    
</iframe>
</body>

</html>


