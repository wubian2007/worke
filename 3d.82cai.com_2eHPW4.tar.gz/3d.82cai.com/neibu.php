<html>

<head>
<meta charset="utf-8">
<title>内部系统</title>
<link rel="stylesheet" type="text/css" href="/theme.css">


</head>
<ul> 
  <li><a class="active" href="/neibu.php">内部主页</a></li>
  <li><a href="/kd.php">KS-3D</a></li>
  <li><a href="/kp.php">KS-P3</a></li>
  <li><a href="/td.php">TI-3D</a></li>
  <li><a href="/tp.php">TI-P3</a></li>
  <li><a href="/ld.php">LD-3D</a></li> 
  <li><a href="/lp.php">LD-P3</a></li>
  <li><a href="https://web.telegram.org">傲视</a></li>
  <li><a href="https://web.telegram.org">天富</a></li>
</ul>
<body>

<h1>请选择自己的表单，不要使用别人的</h1>
</body>

</html>


