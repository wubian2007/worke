
function changeCellColor(sTableId)
{
    var oTbe = document.getElementById(sTableId);
    var td;
    for (var i=0; i<oTbe.rows.length; i++)
    {
        for (var j=0; j<oTbe.rows[i].cells.length; j++)
        {
            with (oTbe.rows[i].cells[j])
            {
                style.background = (innerHTML.indexOf("是") > -1)?"red":"white"; //如果包含‘是’ 背景锯齿 蓝色，不然就红色
            }
        }
    }
}
 
changeCellColor("t1");  //这里是要修改的表字， 需要你提前定义好
changeCellColor("tbe03");
