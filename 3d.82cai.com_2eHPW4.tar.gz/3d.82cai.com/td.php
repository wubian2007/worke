<html>

<head>
<meta charset="utf-8">
<title>系统-TI</title>
<link rel="stylesheet" type="text/css" href="/theme.css">
<?php include('./password/ps-ti.php'); ?>
<?php include('./htm/head.php');//调用的头部文件 ?> 
</head>

<body>
<iframe src ="/3d/3d-t.php" width="380px" height="900px" frameborder="0">
    
 
</iframe>
 
<iframe src ="/fenjie.php" width="450px" height="900px" frameborder="0">
    
 
</iframe>


<iframe src ="/3d/3dzx.php" width="400px" height="900px" frameborder="0">
    
</iframe>

<iframe src ="/3d/3dzx2t.php" width="400px" height="900px" frameborder="0">
    
</iframe>
</body>

</html>


