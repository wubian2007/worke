<ul> 
  <li><a class="active" href="/neibu.php">内部主页</a></li>
  <li><a href="/kd.php">KS-3D</a></li>
  <li><a href="/kp.php">KS-P3</a></li>
  <li><a href="/td.php">TI-3D</a></li>
  <li><a href="/tp.php">TI-P3</a></li>
  <li><a href="/ld.php">LD-3D</a></li> 
  <li><a href="/lp.php">LD-P3</a></li>
  <li><a href="/3d/3dzx2.php">3D投注</a></li>
  <li><a href="/p3/p3zx2.php">P3投注</a></li>
</ul>