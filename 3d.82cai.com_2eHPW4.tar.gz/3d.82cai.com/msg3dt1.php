<?php

$servername = "localhost";

$username = "3dp3";

$password = "aabb8899";

$dbname = "3dp3";

 

// 创建连接

$conn = new mysqli('localhost', $username, $password, $dbname);

// 检测连接

if ($conn->connect_error) {

    die("连接失败: " . $conn->connect_error);

} 



$num7=$_POST["num7"];

$beishu7=$_POST["beishu7"];

$sq4 = "update 3D SET gfdd=('$beishu7') WHERE id=('$num7')";

if ($conn->query($sq4) === TRUE) {

    echo "<script>history.go(-1);</script>";

} else {

    echo "Error: " . $sq4 . "<br>" . $conn->error;

}

$conn->close();
header('location: '.$_SERVER['HTTP_REFERER']);

?>
