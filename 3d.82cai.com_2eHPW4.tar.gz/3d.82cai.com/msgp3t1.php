<?php

$servername = "localhost";

$username = "3dp3";

$password = "aabb8899";

$dbname = "3dp3";

 

// 创建连接

$conn = new mysqli('localhost', $username, $password, $dbname);

// 检测连接

if ($conn->connect_error) {

    die("连接失败: " . $conn->connect_error);

} 



$num2=$_POST["num2"];

$beishu2=$_POST["beishu2"];

$sq4 = "update P3 SET zj=('$beishu2') WHERE id=('$num2')";

if ($conn->query($sq4) === TRUE) {

    echo "<script>history.go(-1);</script>";

} else {

    echo "Error: " . $sq4 . "<br>" . $conn->error;

}

$conn->close();
header('location: '.$_SERVER['HTTP_REFERER']);

?>
