<html>
   <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>登录页面</title>
  <style>
#divcss{margin:300 auto;width:400px;height:40px;}   
#footer {
            height: 40px;
            line-height: 40px;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            background: #373d41;
            color: #ffffff;
            font-family: Arial;
            font-size: 16px;
      
            letter-spacing: 1px;
        }
a {text-decoration: none}
  </style>
</head>
<body>
<?php
//所有需要输出二次密码打开的页面，只需要将本php文件进行包含即可
$url = 'http://'.$_SERVER['SERVER_NAME'].':'.$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
//echo $url;
if (!session_id()){session_start();};
if(isset($_GET['close'])){  
$url = $_GET['url']; 
unset($_SESSION['recheck']);
}
if(isset($_POST['password']) && $_POST['password'] == 'ld2021'){
    $_SESSION['recheck'] = 1;
    header('location:'.$url);
}
if(!isset($_SESSION['recheck'])){
    exit('<div  class="leftbar">
        <form method="post">
            请输入LD密码：<input type="password" name="password" />
            <input type="submit" value="确定" />
        </form>
    </div>
    ');
}
?>
<div id="footer"><a href="?close=yes&url=<?php echo $url?>"><font color="#FFFFFF">安全退出本页面</font></a></div>
</body>
</html>
